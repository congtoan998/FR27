import React from "react";
import "./todoapp.scss"

export default function Button (props){
    return (
      <button type="button" className="btn btn-outline-success" onClick={props.onClick} >ADD</button>
    );
  };