import React from "react";
import "./todoapp.scss"

export default function Header(){
    return(
        <h3 className="header">
        <span className="header__title">My Todos</span>
    </h3>
    )
}
